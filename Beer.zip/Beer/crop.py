from PIL import Image

im = Image.open(r'C:\Users\hp\Desktop\Projects\Spotify\logo.png')
pix = im.load()
dim = im.size
l = []

for j in range(dim[1]):
    for i in range(dim[0]):
        #print(pix[i, j])
        if pix[i, j][:3] != (0,0,0):
            top = j
            break
    else:
        continue
    break

for j in range(dim[1]-1, 0, -1):
    for i in range(dim[0]):
        #print(pix[i, j])
        if pix[i, j][:3] != (0,0,0):
            bottom = j
            break
    else:
        continue
    break
    
for i in range(dim[0]):
    for j in range(dim[1]):
        #print(pix[i, j])
        if pix[i, j][:3] != (0,0,0):
            left = i
            break
    else:
        continue
    break
    
for i in range(dim[0]-1, 0, -1):
    for j in range(dim[1]):
        #print(pix[i, j])
        if pix[i, j][:3] != (0,0,0):
            right = i
            break
    else:
        continue
    break

im1 = im.crop((left,top,right,bottom))
im1.save('C:\\Users\\hp\\Desktop\\empty.png')
