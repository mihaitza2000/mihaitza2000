from PIL import Image
import pygame, random
from random import randint
from pygame import *
from time import sleep

pygame.init()

#global variables
width, height, block, L, level, life, speed, nr = 400, 600, 40, [], 0, 3, 0.4, 500
screen = display.set_mode([height, height])

#images
picture = pygame.image.load(f'./images/pos{level//5+1}_copy.png').convert()
picture = pygame.transform.scale(picture,(height-width, height))

beer = pygame.image.load('./images/beer.png')
beer = pygame.transform.scale(beer,(block/2, 3*block/2))

bg = pygame.image.load('./images/bg.png').convert()
bg = pygame.transform.scale(bg,(width, height))

box = pygame.image.load('./images/box.png').convert()
box = pygame.transform.scale(box,(3*block/2, block))

full = pygame.image.load('./images/full.png').convert()
full = pygame.transform.scale(full, (height-width-block, height-block))

empty = pygame.image.load('./images/empty.png').convert()
empty = pygame.transform.scale(empty, (height-width-block, height-block))


def create_image(nr):
    img1 = Image.open('./images/full.png')
    img2 = Image.open('./images/empty.png')
    pix1 = img1.load()
    pix2 = img2.load()
    dim = img1.size
    for j in range(nr, 0 , -1):
        for i in range(dim[0]):
            pix1[i, j] = pix2[i, j]
    img1 = img1.save('./test.png')

#beer object
class Object:
    def __init__(self, x, y, w, h, img):
        self.x, self.y, self.w, self.h = x, y, w, h
        self.img = img
    def show(self):
        pygame.draw.line(screen, (255,0,0), (width, 0), (width, height), 4)
        screen.blit(self.img, (self.x, self.y))
    def move(self, x):
        self.x, self.rect = x, Rect(self.x, self.y, self.w, self.h)
    def change(self, i):
        self.y += i

#check if cached        
def catch(o, e):
    if not(
    ((e.x >= o.x       and e.x <= o.x + o.w)       and (e.y >= o.y       and e.y <= o.y + o.h))       or 
    ((e.x + e.w >= o.x and e.x + e.w <= o.x + o.w) and (e.y >= o.y       and e.y <= o.y + o.h))       or 
    ((e.x >= o.x       and e.x <= o.x + o.w)       and (e.y + e.h >= o.y and e.y + e.h <= o.y + o.h)) or 
    ((e.x + e.w >= o.x and e.x + e.w <= o.x + o.w) and (e.y + e.h >= o.y and e.y + e.h <= o.y + o.h))):
        return False
    return True

#play function
def play(o, e):
    global level, picture, life, speed
    while level < 35 and life > 0:
        screen.blit(picture, (width, 0))
        screen.blit(bg, (0, 0))
        for i in range(life):
            screen.blit(beer, (i*block/2, 0))
        for event in pygame.event.get():
            if event.type == QUIT:
                quit()
        mouse = pygame.mouse.get_pos()
        o.show()
        e.show()
        e.change(speed)
        if e.y > height or catch(o, e):
            level += 1
            if not catch(o, e):
                life -= 1
            if level % 5 == 0 and level < 35:
                speed += 0.08
                picture = pygame.image.load(f'./images/pos{level//5+1}_copy.png')
                picture = pygame.transform.scale(picture,(height-width, height))
            e.x = randint(0, width-block/2)
            e.y = 0
        if mouse[0] <= width - 1.5*block and o.x <= width - 1.5*block:
            o.move(mouse[0])
        display.flip()
    screen.blit(picture, (width, 0))
    screen.blit(bg, (0, 0))
    if life != 0:
        screen.fill((0,0,0))
        congrats = pygame.image.load("./images/congrats.png").convert()
        congrats = pygame.transform.scale(congrats,(height, height))
        screen.blit(congrats, (0, 0))
    display.flip()
    sleep(5)
    

#main function
if  __name__ == "__main__":
    o = Object(0, height - block, 3*block, block, box)
    e = Object(randint(0, width-block/2), 0, block/2, block, beer)
    play(o, e)